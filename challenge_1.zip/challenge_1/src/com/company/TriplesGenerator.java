package com.company;

import java.util.ArrayList;
import java.util.List;




public class TriplesGenerator {
    public static List<List<Integer>> generate_numbers_from_given_array(int[] numbers, List<Integer> currentnumbers, List<Integer> indexes, int i,
                                                                        List<List<Integer>> result, List<List<Integer>> resIndexes, int currentIndex,int expected_sum) {
        /**
         * recursive function to get possible triples from array
         * this function was built based on dynamic problem algorthim where in for each index in the result that contain three values we go through the given array and decide if we want to add it to our result or not
         * the final result it's an array contain list of arrays each one contain three values each value refer to the index in the given array where these three values refer to numbers that equal expected sum
         *
         *
         * @param numbers the given array.
         * @param currentnumbers this parameter generates array contain three values.
         * @param indexes indexes from array for numbers.
         * @param i where are we in the currentnumber parameter.
         * @param result contain all possible solutions for numbers.
         * @param resIndexes contain all possible indexes.
         * @param currentIndex this for taking order into account.
         * @param expected_sum the given expected sum.
         * @return the cart's inf
         */
        if (i < 3) {
            for (int x = currentIndex; x < numbers.length; x++) {
                /*Apply given concentrates such as unique triples and expected sum*/
                if (currentnumbers.size() <= 3 && (sum(currentnumbers) + numbers[x] <= expected_sum) && (!indexes.contains(x))
                        && (!currentnumbers.contains(numbers[x]))) {
                    /**Generate possible solution**/
                    currentnumbers.add(numbers[x]);
                    indexes.add(x);
                    if (currentnumbers.size() == 3 && sum(currentnumbers) == expected_sum && !resIndexes.contains(indexes)) {
                        /**Add accepted solution for numbers**/
                        result.add(new ArrayList<>(currentnumbers));
                        /**Add accepted solution for indexes**/
                        resIndexes.add(new ArrayList<>(indexes));
                    }
                    i++;
                    /**
                     *go into depth for recursion function
                     *  **/
                    generate_numbers_from_given_array(numbers, currentnumbers, indexes, i, result, resIndexes, x,expected_sum);
                    currentnumbers.remove(currentnumbers.size() - 1);
                    indexes.remove((Integer) x);
                    i--;
                }
            }
            return resIndexes;
        }
        return resIndexes;
    }

    public static List<List<Integer>> get_triples_indexes_for_given_array_and_expected_sum(int[] numbers,int expected_sum) {
        /**
         * This function as interface for input where it takes array of numbers and expected sum.
         * @param numbers the given array.
         * @param expected_sum the given expected sum.
         * **/
        List<List<Integer>> result = new ArrayList<>();
        List<Integer> indexes = new ArrayList<>();
        List<List<Integer>> resIndexes = new ArrayList<>();
        List<Integer> currentnumbers = new ArrayList<>();
        indexes = new ArrayList<>();

        return generate_numbers_from_given_array(numbers, currentnumbers, indexes, 0, result, resIndexes, 0,expected_sum);
    }


    private static int sum(List<Integer> list) {
        int sum = 0;
        for (Integer num : list) {
            sum += num;
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] inputnumbers = {1,0,2,3,4,5,6,3,1,2,0}; // Replace with your input array of integers
        int expected_sum=6;
        List<List<Integer>> result = get_triples_indexes_for_given_array_and_expected_sum(inputnumbers,expected_sum);
        for (List<Integer> numbers : result) {
            System.out.println(numbers);
        }
    }
}
